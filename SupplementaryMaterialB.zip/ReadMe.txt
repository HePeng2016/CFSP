The results from the paper can be reproduced via the code from script.txt.Before running script, install CFSP software is necessary. Due to motif mine algorithm is time-consuming, So the motif files have been generated in miRNA file and piRNA files.  

 